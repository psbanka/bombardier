from bombardier_core.Spkg import SpkgV5
from bombardier_core.static_data import OK, FAIL

import os

class TestBadVerify(SpkgV5):
    """test package"""
    def __init__(self, config):
        """Init function, pulls config info into class."""
        SpkgV5.__init__(self, config)

    def configure(self):
        """Configuration entry point for bombardier"""
        return OK

    def install(self):
        """Install entry point for bombardier"""
        self.configure()

    def uninstall(self):
        """Uninstall entry point for bombardier."""
        return OK

    def verify(self):
        """Verification entry point for bombardier. Stub atm"""
        return FAIL

