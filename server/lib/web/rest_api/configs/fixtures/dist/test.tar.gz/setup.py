# setup.py: sets bombardier up.

from distutils.core import setup
setup (name = "EMPTY_TEST",
       description = "Open Source Empty package",
       version = "1",
       packages = [],
       author = "Peter Banka and Shawn Sherwood",
       author_email = "peter.banka@gmail.com",
       url = "http://bombardierinstaller.org/"
)
