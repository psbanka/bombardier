#!/usr/local/bin/python2.4

from bombardier_core.static_data import OK, FAIL
from bombardier_core.Spkg import SpkgV5
from TestLib import TestLib
import shutil, os

class TestPackage(SpkgV5):

    def __init__(self, config):
        SpkgV5.__init__(self, config)
        os.chdir("TestInjector")
        self.thing = config.string("test.value", "foo")
        self.directory = config.string("test.directory", r"/tmp/test")
        if not self.directory:
            self._error("self.directory is not set")
        self.test_path  = os.path.join(self.directory, "TEST.TXT")

    def configure(self):
        self._info( "configuring..." )
        tl = TestLib.TestLib("value")
        assert tl.check() == "value"
        open(self.test_path, 'w').write(self.thing)
        return OK

    def install(self):
        self._info( "installing..." )
        if not os.path.isdir(self.directory):
            self._info("creating directory %s" % self.directory)
            os.makedirs(self.directory)
        file_name = "testFile.txt"
        src = file_name
        dst = os.path.join(self.directory, file_name)
        self._info("Copying %s to %s" % (file_name, dst))
        shutil.copy(file_name, dst)
        self.configure()
        return OK

    def uninstall(self):
        self._info( "uninstalling..." )
        os.unlink(self.test_path)
        if os.path.isdir(self.directory):
            self._info("removing directory %s" % self.directory)
            os.rmdir(self.directory)
        return OK

    def verify(self):
        self._info( "verify..." )
        if os.path.isdir(self.directory):
            data = open(self.test_path).read()
            if data == self.thing:
                return OK
        return FAIL
