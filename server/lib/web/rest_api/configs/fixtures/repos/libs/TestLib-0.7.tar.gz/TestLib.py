"Does nothing at all"

class TestLib:
    "Class for Bombardier type-5 testing"

    def __init__(self, var):
        self.var = var

    def check(self):
        return self.var
