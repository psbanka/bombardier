#!/usr/local/bin/python2.4

from bombardier_core.static_data import OK, FAIL
from bombardier_core.Spkg import SpkgV5
import shutil, os

class TestT5Backup(SpkgV5):

    def __init__(self, config):
        SpkgV5.__init__(self, config)
        self.target_path = config.string("test.directory", r"/tmp/foogazi")
        self.target_file = os.path.join(self.target_path, "test_type_5")

    def backup(self):
        target_dict = {"main_file": {"file_name": self.target_file},
                       "__pre_backup__": "stop",
                       "__post_backup__": "start",
                      }
        return target_dict
        #return self._backup(target_dict)

    def start(self):
        open(self.target_file, 'a').write("STARTED\n")
        return OK
        
    def stop(self):
        open(self.target_file, 'a').write("STOPPED\n")
        return OK
        
    def configure(self):
        self._info( "configuring..." )
        return OK

    def install(self):
        self._info( "installing..." )
        os.system("mkdir -p %s" % self.target_path)
        open(self.target_file, 'w').write("INSTALLED\n")
        self.configure()
        return OK

    def uninstall(self):
        self._info( "UN installing..." )
        return OK

    def verify(self):
        self._info( "verify..." )
        if not os.path.isfile(self.target_file):
            self._error("%s does not exist. Install failed." % self.target_file)
            return FAIL
        return OK
