#!/usr/local/bin/python2.4

from bombardier_core.static_data import OK, FAIL
from bombardier_core.Spkg import SpkgV5
import shutil, os

class TestT5Backup(SpkgV5):

    def __init__(self, config):
        SpkgV5.__init__(self, config)
        self.target_path = config.string("test.directory", r"/tmp/foogazi")
        self.target_file = os.path.join(self.target_path, "test_type_5")
        self.pre_backup = "stop"
        self.pre_restore = "stop"
        self.post_backup = "start"
        self.post_restore = "start"

    def restore(self, restore_path):
        self._info("TESTT5BACKUP: restore_path:: {0} ::".format(restore_path))
        if not os.path.isdir(restore_path):
            self._error("TestT5Backup:: %s does not exist." % restore_path)
            return FAIL
        restore_source = os.path.join(restore_path, self.target_file[1:])
        if not os.path.isfile(restore_source):
            self._error("TestT5Backup:: %s does not exist." % restore_source)
            return FAIL
        status = os.system("mv {0} {1}".format(restore_source, self.target_path))
        if status != OK:
            self._error("TestT5Backup:: Unable to move {0} to {1}".format(restore_path, self.target_path))
            return FAIL
        return OK

    def backup(self):
        return {"file_names": [self.target_file]}

    def start(self):
        open(self.target_file, 'a').write("STARTED\n")
        return OK
        
    def stop(self):
        open(self.target_file, 'a').write("STOPPED\n")
        return OK
        
    def configure(self):
        self._info( "configuring..." )
        return OK

    def install(self):
        self._info( "installing..." )
        os.system("mkdir -p %s" % self.target_path)
        open(self.target_file, 'w').write("INSTALLED\n")
        self.configure()
        return OK

    def uninstall(self):
        self._info( "UN installing..." )
        return OK

    def verify(self):
        self._info( "verify..." )
        if not os.path.isfile(self.target_file):
            self._error("%s does not exist. Install failed." % self.target_file)
            return FAIL
        return OK
