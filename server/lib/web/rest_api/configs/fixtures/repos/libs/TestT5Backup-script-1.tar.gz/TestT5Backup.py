#!/usr/local/bin/python2.4

from bombardier_core.static_data import OK, FAIL
from bombardier_core.Spkg import SpkgV5
import shutil, os

class TestT5Backup(SpkgV5):

    def __init__(self, config):
        SpkgV5.__init__(self, config)
        self.target_file = config.string("test.target_file", r"/etc/hosts")

    def backup(self):
        target_dict = {"main_file": {"file_name": self.target_file}}
        return SpkgV5._backup(self, target_dict)

    def configure(self):
        self._info( "configuring..." )
        return OK

    def install(self):
        self._info( "installing..." )
        self.configure()
        return OK

    def uninstall(self):
        self._info( "UN installing..." )
        return OK

    def verify(self):
        self._info( "verify..." )
        if not os.path.isfile(self.target_file):
            self._error("%s does not exist. Cannot install." % self.target_file)
            return FAIL
        return OK
