#!/cygdrive/c/Python23/python.exe

import os
import shutil

BASE_DIR = "c:\\secure"

if os.path.isdir(BASE_DIR):
    shutil.rmtree(BASE_DIR)

os.makedirs(BASE_DIR)

for inode in os.listdir('.'):
    if os.path.isfile(inode):
        src = inode
        dst = os.path.join(BASE_DIR, inode)
        print "copying %s -> %s" % (src, dst)
        try:
            shutil.copy(src, dst)
        except:
            print "Error copying %s" % src
